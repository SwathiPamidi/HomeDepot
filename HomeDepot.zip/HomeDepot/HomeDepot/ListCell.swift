//
//  ListCell.swift
//  HomeDepot
//
//  Created by Swathi on 12/18/18.
//  Copyright © 2018 Swathi. All rights reserved.
//

import UIKit

class ListCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel?
    @IBOutlet weak var desc: UILabel?
    @IBOutlet weak var dateLabel: UILabel?
    @IBOutlet weak var license: UILabel?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
