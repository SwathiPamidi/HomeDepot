//
//  ViewController.swift
//  HomeDepot
//
//  Created by Swathi on 12/18/18.
//  Copyright © 2018 Swathi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var segmentCtrl : UISegmentedControl!
    
    @IBOutlet weak var gridHolder : UIView!
    @IBOutlet weak var gridView : UICollectionView!
    
    @IBOutlet weak var listHolder : UIView!
    @IBOutlet weak var listView : UITableView!
    var pageNum = 1
    
    var dataSource : [[String:String]]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        dataSource = [[String:String]]()
        getJsonFromUrl(pageNum: pageNum)
        
        if segmentCtrl.selectedSegmentIndex == 0{
            //load list view
            self.listView.reloadData()
            self.listHolder.isHidden = false
            self.gridHolder.isHidden = true
        }else{
            //load grid view
            self.gridView.reloadData()
            self.listHolder.isHidden = true
            self.gridHolder.isHidden = false
        }
        
    }
    
    func getJsonFromUrl(pageNum : Int){
        
        //creating a NSURL
        let url = URL(string: "https://api.github.com/users/apple/repos?page=\(pageNum)&per_page=10")
        
        //fetching the data from the url
        URLSession.shared.dataTask(with: url!, completionHandler: {(data, response, error) -> Void in
            
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! Array<Any> {
                
                for dic in jsonObj{
                    if let dic = dic as? Dictionary<String,Any>{
                        var tempData = [String:String]()
                        if let name = dic["name"] as? String{
                            tempData["name"] = name
                        }
                        if let desc = dic["description"] as? String{
                            tempData["description"] = desc
                        }
                        if let create_date = dic["created_at"] as? String{
                            tempData["created_at"] = create_date
                        }
                        if let lic = dic["license"] as? Dictionary<String,String>{
                            if let name = lic["name"]{
                                tempData["license"] = name
                            }
                        }
                        self.dataSource?.append(tempData)
                    }
                }
                OperationQueue.main.addOperation({
                    
                    if self.segmentCtrl.selectedSegmentIndex == 0{
                        //load list view
                        self.listView.reloadData()
                        self.listHolder.isHidden = false
                        self.gridHolder.isHidden = true
                    }else{
                        //load grid view
                        self.gridView.reloadData()
                        self.listHolder.isHidden = true
                        self.gridHolder.isHidden = false
                    }
                    
                })
            }
        }).resume()
    }
    
    
    @IBAction func segChnaged(sender: UISegmentedControl){
        
        if sender.selectedSegmentIndex == 0{
            //load list view
            self.listView.reloadData()
            self.listHolder.isHidden = false
            self.gridHolder.isHidden = true
            
        }else{
            //load grid view
            self.gridView.reloadData()
            self.listHolder.isHidden = true
            self.gridHolder.isHidden = false
            
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let  height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom < height {
            pageNum += 1
            getJsonFromUrl(pageNum: pageNum)
        }
    }
    
    
}

extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath) as? ListCell
        
        if let dic = dataSource?[indexPath.row]{
            if let name = dic["name"]{
                cell?.name?.text = name
            }
            if let desc = dic["description"]{
                cell?.desc?.text = desc
            }
            if let create_date = dic["created_at"]{
                cell?.dateLabel?.text = create_date
            }
            if let lic = dic["license"]{
                cell?.license?.text = lic
            }
        }
        
        
        return cell!
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if let count = dataSource?.count{
            return count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}


extension ViewController : UICollectionViewDataSource, UICollectionViewDelegate{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let count = dataSource?.count{
            return count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "gridCell", for: indexPath) as? GridCell
        
        if let dic = dataSource?[indexPath.row]{
            if let name = dic["name"]{
                cell?.name?.text = name
            }
            if let desc = dic["description"]{
                cell?.desc?.text = desc
            }
            if let create_date = dic["created_at"]{
                cell?.dateLabel?.text = create_date
            }
            if let lic = dic["license"]{
                cell?.license?.text = lic
            }
        }
        
        return cell!
    }
    
    func collectionView(collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        return CGSize(width: gridView.frame.size.width/2, height: 100)
    }
    
    //Use for interspacing
    func collectionView(collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 1.0
    }
    
    func collectionView(collectionView: UICollectionView, layout
        collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 1.0
    }
    
    
}


