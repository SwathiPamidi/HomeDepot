//
//  GridCell.swift
//  HomeDepot
//
//  Created by Swathi on 12/18/18.
//  Copyright © 2018 Swathi. All rights reserved.
//

import UIKit

class GridCell: UICollectionViewCell {
    
    @IBOutlet weak var name: UILabel?
    @IBOutlet weak var desc: UILabel?
    @IBOutlet weak var dateLabel: UILabel?
    @IBOutlet weak var license: UILabel?
    
    
}
